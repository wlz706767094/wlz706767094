<?php /*a:6:{s:54:"E:\mywork\th\application\index\view\user\register.html";i:1592206293;s:52:"E:\mywork\th\application\index\view\public\base.html";i:1591756506;s:51:"E:\mywork\th\application\index\view\public\nav.html";i:1592364481;s:51:"E:\mywork\th\application\index\view\Public\reg.html";i:1592805607;s:53:"E:\mywork\th\application\index\view\public\right.html";i:1592204881;s:54:"E:\mywork\th\application\index\view\public\footer.html";i:1592204884;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title><?php echo htmlentities((isset($title) && ($title !== '')?$title:"技术热点")); ?></title>
	
<link rel="stylesheet" type="text/css" href="/static/bootstrap/css/bootstrap.css" />
<script type="text/javascript" src="/static/jquery/jquery.min.js"></script>
<script type="text/javascript" src="/static/bootstrap/js/bootstrap.js"></script>

</head>
<body>
	<header>
		<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="col-md-2"></div>
    <div class="col-md-8">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">技术热点</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo url('index/index'); ?>">首页 <span class="sr-only">(current)</span></a></li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">ThinkPHP <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">PHP</a></li>
            <li><a href="#">MySQL</a></li>
            <li><a href="#">redis</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Html5+Css3</a></li>
            <li><a href="#">JavaScript</a></li>
            <li><a href="#">Vue.js</a></li>
          </ul>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
      	<li>
      		<form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search" name="search">
        </div>
        <button type="submit" class="btn btn-default">搜索</button>
      </form>
      	</li>
        <?php if(!app('session')->get('user_name')): ?>
        <li><a href="<?php echo url('index/user/login'); ?>">登录</a></li>
        <li><a href="<?php echo url('index/user/register'); ?>">注册</a></li>
        <?php else: ?>
        <li><a href=""><?php echo htmlentities(app('session')->get('user_name')); ?></a></li>
        <li><a href="">发布热点</a></li>
        <li><a href="<?php echo url('user/logout'); ?>">退出</a></li>
        <?php endif; ?>
        <!-- <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">操作 <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
          </ul>
        </li> -->
      </ul>
    </div><!-- /.navbar-collapse -->
	</div>
    <div class="col-md-2"></div>
  </div><!-- /.container-fluid -->
</nav>
	</header>
	<section>
		
<div class="container-fluid">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <div class="row">
            <div class="col-md-8">
            	<div class="page-header">
  <h2>用户注册</h2>
</div>
<form id="frm" class="form-horizontal" novalidate>
  <div class="form-group">
    <label for="name" class="col-sm-2 control-label">用户名</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="用户名" name="name">
    </div>
  </div>
  <div class="form-group">
    <label for="email" class="col-sm-2 control-label">邮箱</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" id="email" placeholder="邮箱" name="email">
    </div>
  </div>
    <div class="form-group">
    <label for="mobile" class="col-sm-2 control-label">电话</label>
    <div class="col-sm-10">
      <input type="phone" class="form-control" id="mobile" placeholder="电话" name="mobile">
    </div>
  </div>
  <div class="form-group">
    <label for="password" class="col-sm-2 control-label">密码</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="password" placeholder="密码" name="password">
    </div>
  </div>
    <div class="form-group">
    <label for="password_confirm" class="col-sm-2 control-label">确认密码</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="password_confirm" placeholder="确认密码" name="password_confirm">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <div class="checkbox">
        <label>
          <input type="checkbox"> 我同意用户协议
        </label>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button id="reg" type="submit" class="btn btn-default">注册</button>
    </div>
  </div>
</form>

<script>
  $(function(){
    $("#reg").on('click',function(e){
      e.preventDefault();
      $.ajax({
        type:"post",
        url:"<?php echo url('index/user/insert'); ?>",
        data:$('#frm').serialize(),
        dataType:"json",
        success:function(data){
          // console.log(data);
          switch(data['status']){
            case 1:alert(data["message"]);
            window.location.href="<?php echo url('index/index/index'); ?>";
            break;
            case -1:alert(data["message"]);
            window.location.href="<?php echo url('index/user/register'); ?>";
            break;
            case 0:alert(data["message"]);
            window.location.href="<?php echo url('index/user/register'); ?>";
            break;
          }
         }
      })
    })
  })
</script>
            </div>
            <div class="col-md-4">
            	<div class="page-header">
  <h2>热点排行</h2>
</div>
<div class="list-group">
  <a href="#" class="list-group-item active">
    最新热点
  </a>
  <a href="#" class="list-group-item">Dapibus ac facilisis in</a>
  <a href="#" class="list-group-item">Morbi leo risus</a>
  <a href="#" class="list-group-item">Porta ac consectetur ac</a>
  <a href="#" class="list-group-item">Vestibulum at eros</a>
  <a href="#" class="list-group-item">Porta ac consectetur ac</a>
  <a href="#" class="list-group-item">Vestibulum at eros</a>
</div>

            </div>
        </div>
    </div>
    <div class="col-md-2"></div>
</div>

	</section>
	<footer>
		<div class="container-fluid">
	<p class="text-center bg">Copyright &copy;2020 cvit.com.cn</p>
</div>

<style>
	.bg {
		background: #999;
		color: #fff;
		margin: 20px 0;
		height: 80px;
		line-height: 80px;
	}
</style>
	</footer>
</body>
</html>